import streamlit as st
import pandas as pd
from detect import *
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from tried import *
s=1

def entry(s,x):
    global slot
    slot=[]
    slot.append(x)
    s=s+1
    
    if s>0:
        global k
        k=[]
        for i in range(1,s):
            n=str(i)
            k.append(i)
            with  c1:
                render_labeled_rectangle("SLOT "+ n, "red")

    
        for i in range(s,16):
            
            if i%3==1:
                n=str(i)
                with  c1:
                    render_labeled_rectangle("SLOT "+ n, "green" )
                  
            if i%3==2:
                n=str(i)
                with  c2:
                    render_labeled_rectangle("SLOT "+ n, "green" )
                
            if i%3==0:
                n=str(i)
                with  c3:
                    render_labeled_rectangle("SLOT "+ n, "green" )
                

        return slot
def exit(y):
    w=[]
    for i in range(1,s):
        if y==slot[i-1]:
            w.append(i)
    a=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

    for i in range(1,len(w)+1):
            if a[i]==w[i-1]:
                for j in range(1,16):
                    if i%3==1:
                        n=str(i)
                        with  c1:
                            render_labeled_rectangle("SLOT "+ n, "green" )
                    
                    if i%3==2:
                        n=str(i)
                        with  c2:
                            render_labeled_rectangle("SLOT "+ n, "green" )
                    
                    if i%3==0:
                        n=str(i)
                        with  c3:
                            render_labeled_rectangle("SLOT "+ n, "green" )
                
    

data=pd.read_csv('data.csv')

def render_labeled_rectangle(label, color):
    rectangle_style = f"""
        width: 100px;
        height: 80px;
        padding: 10px;
        text-align: center;
        display: flex;
        align-items: center;
        background-color: {color};
    """
    st.markdown(f'<div style="{rectangle_style}" >{label}</div>', unsafe_allow_html=True)
    
st.set_page_config(layout='wide')

with st.sidebar:
    st.image('clipart1550382.png')
    st.title('Automatic Car Parking System')
    st.info('This application is originally developed')


col1, col2 = st.columns(2)

with col1:
    st.table(data)

with col2:
    
    en,ex = st.columns(2)
    c1, c2, c3 = st.columns(3)
    with en:
        
        if st.button("Entry"):
            x=output()
            
            entry(s,x)
            s=2
          
    with ex:

        if st.button("Exit"):
            y=exput()
            
            exit(y)


    if s==1:
        slot1, slot2, slot3 = st.columns(3)
        with slot1:
            render_labeled_rectangle("SLOT 1", "green")
            
            
        with slot2:
            render_labeled_rectangle("SLOT 2", "green")

        with slot3:
            render_labeled_rectangle("SLOT 3", "green")

        st.write("\n")

        slot4, slot5, slot6 = st.columns(3)
        with slot4:
            render_labeled_rectangle("SLOT 4", "green")
        
        with slot5:
            render_labeled_rectangle("SLOT 5", "green")

        with slot6:
            render_labeled_rectangle("SLOT 6", "green")
        
        st.write(" \n")

        slot7, slot8, slot9 = st.columns(3)
        with slot7:
            render_labeled_rectangle("SLOT 7", "green")
        
        with slot8:
            render_labeled_rectangle("SLOT 8", "green")

        with slot9:
            render_labeled_rectangle("SLOT 9", "green")
        
        st.write("  \n ")

        slot10, slot11, slot12 = st.columns(3)
        with slot10:
            render_labeled_rectangle("SLOT 10", "green")
        
        with slot11:
            render_labeled_rectangle("SLOT 11", "green")

        with slot12:
            render_labeled_rectangle("SLOT 12", "green")

        st.write("\n")

        slot13, slot14, slot15 = st.columns(3)
        with slot13:
            render_labeled_rectangle("SLOT 13", "green")
        
        with slot14:
            render_labeled_rectangle("SLOT 14", "green")

        with slot15:
            render_labeled_rectangle("SLOT 15", "green")
        
        st.write('\n')
        st.write('\n')
    

    
        




            
            
            
            

    
    


    

