import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import cv2
import pytesseract

# Load the data from the CSV file
data = pd.read_csv('data.csv')

# Define the path to the directory containing the images
image_directory = 'path/to/your/images/'

# Create a DataFrame to store the image paths and corresponding actual values
image_data = {'image_path': [], 'actual_value': []}

# Loop through each image
for i in range(1, 16):
    image_path = f'{image_directory}image_{i}.png'
    actual_value = data['actual_value_column'].iloc[i - 1]
    image_data['image_path'].append(image_path)
    image_data['actual_value'].append(actual_value)

# Create a DataFrame from the image data
df_images = pd.DataFrame(image_data)

# Split the data into training and testing sets
train_data, test_data = train_test_split(df_images, test_size=0.2, random_state=42)

# Function to extract text using Tesseract OCR
def extract_text(image_path):
    img = cv2.imread(image_path)
    return pytesseract.image_to_string(img).strip()

# Apply the text extraction function to the test set
test_data['extracted_text'] = test_data['image_path'].apply(extract_text)

# Calculate accuracy
accuracy = accuracy_score(test_data['actual_value'], test_data['extracted_text'])

# Print the accuracy
print(f"Accuracy: {accuracy * 100:.2f}%")

 