import cv2
import pytesseract
import imutils
import numpy as np

# Path to the Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r'C:\\\Users\\\kmadh\\\Tesseract-OCR\\\tesseract'

# Load the image
image_path = 'images/15.jpg'
img = cv2.imread(image_path)

# Resize the image for better processing
img = imutils.resize(img, width=500)

# Convert the image to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Apply bilateral filter to reduce noise while preserving edges
gray = cv2.bilateralFilter(gray, 11, 17, 17)

# Use adaptive thresholding to emphasize edges in the image
thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)

# Find contours in the thresholded image
cnts, _ = cv2.findContours(thresh.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[:30]
NumberPlateCnt = None

# Iterate through contours to find a rectangular region (assuming the number plate is rectangular)
for c in cnts:
    peri = cv2.arcLength(c, True)
    approx = cv2.approxPolyDP(c, 0.02 * peri, True)
    if len(approx) == 4:
        NumberPlateCnt = approx
        break

# Masking the part other than the number plate
mask = np.zeros(gray.shape, np.uint8)
cv2.drawContours(mask, [NumberPlateCnt], 0, 255, -1)
new_image = cv2.bitwise_and(img, img, mask=mask)

# Convert the masked image to grayscale
gray_plate = cv2.cvtColor(new_image, cv2.COLOR_BGR2GRAY)

# Threshold the grayscale image
_, thresh_plate = cv2.threshold(gray_plate, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Extract text using Tesseract OCR
config = r'--oem 3 --psm 6 outputbase alphanumeric'
text = pytesseract.image_to_string(thresh_plate, config=config)

# Print the extracted text
print("Extracted Text:", text)

# Show the original image with the detected contours
cv2.drawContours(img, [NumberPlateCnt], 0, (0, 255, 0), 3)
cv2.imshow("Original Image with Contours", img)
cv2.waitKey(0)
cv2.destroyAllWindows()

