import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# Load the CSV file
csv_file = 'program_output.csv'
df = pd.read_csv(csv_file)

# Convert columns to strings
actual_output = df['act_num'].astype(str)
ocr_output = df['vehicle_number'].astype(str)

# Calculate accuracy
accuracy = accuracy_score(actual_output, ocr_output)
print(f"Accuracy: {accuracy * 100:.2f}%")

# Calculate precision, recall, and F1-score
precision = precision_score(actual_output, ocr_output, average='weighted')
recall = recall_score(actual_output, ocr_output, average='weighted')
f1 = f1_score(actual_output, ocr_output, average='weighted')

print(f"Precision: {precision * 100:.2f}%")
print(f"Recall: {recall * 100:.2f}%")
print(f"F1-score: {f1 * 100:.2f}%")

# Generate confusion matrix
conf_matrix = confusion_matrix(actual_output, ocr_output)
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=df['vehicle_number'].unique(), yticklabels=df['act_num'].unique())
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

